<?php

    return array(
        'backup' => array(
            'Backups' => 'Backups',
            'Backup' => 'Backup',
            'Create Backup' => 'Criar Backup',
            'Delete' => 'Deletar',
            'storage' => 'storage',
            'public' => 'public',
            'plugins' => 'plugins',
            'Size' => 'Tamanho',
            'Actions' => 'Ações',
            'Delete backup: :backup' => 'Deletar o backup: :backup',
            'Creating...' => 'Criando backup...',
        )
    );
