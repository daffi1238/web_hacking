<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Pano',
            'Dashboard plugin for Monstra' => 'Monstra için pano eklentisi',
            'Welcome back' => 'Merhaba',
            'Create New' => 'Yeni Oluştur',
            'Upload File' => 'Dosya Yükle',
        )
    );
