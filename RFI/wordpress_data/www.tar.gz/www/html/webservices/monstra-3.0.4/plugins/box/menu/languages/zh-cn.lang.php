<?php

    return array(
        'menu' => array(
            'Menu' => '菜单',
            'Menu manager' => '菜单管理',
            'Edit' => '编辑',
            'Name' => '名称',
            'Delete' => '删除',
            'Order' => '顺序',
            'Actions' => '操作',
            'Create New Item' => '创建新项目',
            'New item' => '新项目',
            'Item name' => '项目名称',
            'Item order' => '项目顺序',
            'Item target' => '项目目标',
            'Item link' => '项目链接',
            'Item category' => '项目类别',
            'Save' => '保存',
            'Edit item' => '布局项目',
            'Delete item :name' => '删除项目 :name',
            'Select page' => '选择页面',
            'Category' => '类别',
            'Select category' => '选择类别',
            'Required field' => '必填字段',
        )
    );
