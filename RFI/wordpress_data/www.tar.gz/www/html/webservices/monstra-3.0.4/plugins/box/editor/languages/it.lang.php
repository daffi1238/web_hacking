<?php

    return array(
        'Editor' => array(
            'Editor' => 'Editor',
            'Editor plugin' => 'Editor plugin',
        )
    );
