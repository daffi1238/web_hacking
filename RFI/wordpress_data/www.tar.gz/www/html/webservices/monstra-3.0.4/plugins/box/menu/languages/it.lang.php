<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Gestione menu',
            'Edit' => 'Modifica',
            'Name' => 'Nome',
            'Delete' => 'Elimina',
            'Order' => 'Ordine',
            'Actions' => 'Azioni',
            'Create New Item' => 'Crea nuova voce',
            'New item' => 'Nuova voce',
            'Item name' => 'Nome',
            'Item order' => 'Ordine',
            'Item target' => 'Target',
            'Item link' => 'Collegamento',
            'Item category' => 'Categoria',
            'Save' => 'Salva',
            'Edit item' => 'Modifica voce menu',
            'Delete item :name' => 'Elimina voce menu :name',
            'Select page' => 'Scegli pagina',
            'Category' => 'Categoria',
            'Select category' => 'Scegli categoria',
            'Required field' => 'Campo obbligatorio',
            'Cancel' => 'Cancel',
        )
    );
