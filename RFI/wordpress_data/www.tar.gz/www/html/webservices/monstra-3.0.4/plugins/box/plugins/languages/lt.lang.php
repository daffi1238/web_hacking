<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Papildiniai',
            'Name' => 'Pavadinimas',
            'Actions' => 'Veiksmai',
            'Description' => 'Aprašymas',
            'Installed' => 'Įdiegti',
            'Install New' => 'Įdiegti naują',
            'Delete' => 'Ištrinti',
            'Delete plugin :plugin' => 'Ištrinti papildinį :plugin',
            'This plugins does not exist' => 'Tokio papildinio nėra',
            'Version' => 'Versija',
            'Author' => 'Autorius',
            'Get More Plugins' => 'Gauti daugiau papildinių',
            'Install' => 'Įdiegti',
            'Uninstall' => 'Išdiegti',
            'README.md not found' => 'README.md not found',
        )
    );
