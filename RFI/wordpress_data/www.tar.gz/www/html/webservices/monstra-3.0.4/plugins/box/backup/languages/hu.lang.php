<?php

    return array(
        'backup' => array(
    		'Backups' => 'Biztonsági mentések',
            'Backup date' => 'Biztonsági mentés dátuma',
    		'Create Backup' => 'Biztonsági mentés készítése',
    		'Delete' => 'Töröl',
            'storage' => 'tárol',
            'public' => 'nyilvános',
            'plugins' => 'pluginok',
            'Size' => 'Méret',
            'Actions' => 'Műveletek',
            'Delete backup: :backup' => 'Biztonsági mentés törlése: :backup',
            'Creating...' => 'Készítés...',
        )
	);