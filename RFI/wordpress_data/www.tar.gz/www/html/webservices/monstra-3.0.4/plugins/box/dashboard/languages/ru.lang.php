<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Панель',
            'Dashboard plugin for Monstra' => 'Панель для Monstra',
            'Welcome back' => 'Добро пожаловать',
            'Create New' => 'Добавить',
            'Upload File' => 'Загрузить Файл',
        )
    );
