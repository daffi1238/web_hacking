<?php

    return array(
        'Editor' => array(
            'Editor' => 'Редактор',
            'Editor plugin' => 'Редактор плагин',
        )
    );
