<?php
    return array(
        'Editor' => array(
            'Editor' => 'რედაქტორი',
            'Editor plugin' => 'პლაგინი რედაქტორი',
        )
    );
