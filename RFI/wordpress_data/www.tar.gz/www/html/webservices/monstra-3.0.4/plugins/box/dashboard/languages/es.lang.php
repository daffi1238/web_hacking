<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Escritorio',
            'Dashboard plugin for Monstra' => 'Dashboard plugin for Monstra',
            'Welcome back' => 'Bienvenido nuevamente',
            'Create New' => 'Crear nuevo',
            'Upload File' => 'Subir archivo',
        )
    );
