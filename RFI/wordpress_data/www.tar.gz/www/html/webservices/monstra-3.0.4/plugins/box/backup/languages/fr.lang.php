<?php

    return array(
        'backup' => array(
            'Backups' => 'Sauvegardes',
            'Backup date' => 'Date de la sauvegarde',
            'Create backup' => 'Créer une sauvegarde',
            'Delete' => 'Supprimer',
            'storage' => 'stockage',
            'public' => 'public',
            'plugins' => 'plugins',
            'Size' => 'Taille',
            'Actions' => 'Actions',
            'Delete backup: :backup' => 'Supprimer la sauvegarde: :backup',
            'Creating...' => 'Création...',
        )
    );