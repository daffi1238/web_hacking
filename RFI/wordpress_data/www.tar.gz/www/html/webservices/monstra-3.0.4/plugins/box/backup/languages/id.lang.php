<?php

    return array(
        'backup' => array(
                    'Backups' => 'Cadangan',
            'Backup date' => 'Tanggal Cadangan',
                    'Create Backup' => 'Buat Cadangan',
                    'Delete' => 'Hapus',
            'storage' => 'Penyimpanan',
            'public' => 'Umum',
            'plugins' => 'Plugins',
            'Size' => 'Ukuran',
            'Actions' => 'Tindakan',
            'Delete backup: :backup' => 'Hapus Cadangan: :backup',
            'Creating...' => 'Dibuat...',
        )
        );
