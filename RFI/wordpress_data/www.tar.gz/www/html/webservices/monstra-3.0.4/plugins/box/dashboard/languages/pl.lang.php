<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Kokpit',
            'Dashboard plugin for Monstra' => 'Wtyczka kokpitu dla systemu Monstra',
            'Welcome back' => 'Witam ponownie',
            'Create New' => 'Utwórz nowy',
            'Upload File' => 'Prześlij plik',
        )
    );
