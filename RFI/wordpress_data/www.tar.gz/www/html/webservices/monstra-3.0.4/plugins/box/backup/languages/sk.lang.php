<?php

    return array(
        'backup' => array(
            'Backups' => 'Zálohy',
            'Backup' => 'Zálohy',
            'Create Backup' => 'Vytvoriť Zálohu',
            'Delete' => 'Vymazať',
            'storage' => 'Storage/Obsah diskového miesta',
            'public' => 'Verejné',
            'plugins' => 'Pluginy',
            'Size' => 'Veľkosť',
            'Actions' => 'Akcie',
            'Delete backup: :backup' => 'Vymazať zálohu: :backup',
            'Creating...' => 'Vytváram...',
        )
    );
