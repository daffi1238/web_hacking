<?php
    return array(
        'dashboard' => array(
            'Dashboard' => 'Komandna tabla',
            'Dashboard plugin for Monstra' => 'Komandna tabla dodatak za Monstra',
            'Welcome back' => 'Dobrodošli natrag',
            'Create New' => 'Kreiraj novo',
            'Upload File' => 'Otpremi fajl',
        )
    );
