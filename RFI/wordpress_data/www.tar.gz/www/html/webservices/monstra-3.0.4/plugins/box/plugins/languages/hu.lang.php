<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Pluginok',
            'Name' => 'Név',
            'Actions' => 'Műveletek',
            'Description' => 'Leírás',
            'Installed' => 'Telepítve',
            'Install New' => 'Új Telepítése',
            'Delete' => 'Törlés',
            'Delete plugin :plugin' => 'Plugin törlése :plugin',
            'This plugin does not exist' => 'Ez a plugin nem létezik',
            'Version' => 'Verzió',
            'Author' => 'Szerző',
            'Get More Plugins' => 'Még több Plugin',
            'Install' => 'Telepít',
            'Uninstall' => 'Töröl',
            'README.md not found' => 'README.md not found',
        )
    );
