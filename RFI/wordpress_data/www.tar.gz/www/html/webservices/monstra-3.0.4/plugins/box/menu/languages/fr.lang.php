<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',        
            'Menu manager' => 'Gestionnaire du menu',
            'Edit' => 'Editer',
            'Name' => 'Nom',
            'Delete' => 'Supprimer',
            'Order' => 'Ordre',
            'Actions' => 'Actions',
            'Create new item' => 'Créer un nouvel item',
            'New item' => 'Nouveau item',
            'Item name' => 'Nom de l\'item',
            'Item order' => 'Ordre de l\'item',
            'Item target' => 'Cible de l\'item',
            'Item link' => 'Lien de l\'item',
            'Item category' => 'Catégorie de l\'item',
            'Save' => 'Enregistrer',
            'Edit item' => 'Editer l\'item',
            'Delete item :name' => 'Supprimer l\'item :name',
            'Select page' => 'Sélectionner la page',
            'Category' => 'Catégorie',
            'Select category' => 'Sélectionner une catégorie',
            'Required field' => 'Champ requis',
            'Cancel' => 'Cancel',
        )
    );