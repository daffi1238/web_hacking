<?php

    return array(
        'backup' => array(
            'Backups' => 'Бекапи',
            'Backup' => 'Бекап',
            'Create Backup' => 'Зробити бекап',
            'Delete' => 'Видалити',
            'storage' => 'дані',
            'public' => 'публічна',
            'plugins' => 'плагіни',
            'Size' => 'Розмір',
            'Actions' => 'Дії',
            'Delete backup: :backup' => 'Видалити бекап: :backup',
            'Creating...' => 'Створення...',
        )
    );
