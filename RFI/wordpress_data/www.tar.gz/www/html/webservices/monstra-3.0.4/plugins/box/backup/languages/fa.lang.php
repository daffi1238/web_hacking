<?php

    return array(
        'backup' => array(
    		'Backups' => 'پشتیبان گیری',
            'Backup Date' => 'تاریخ پشتیبان گیری',
    		'Create Backup' => 'ایجاد نسخه پشتیبان',
    		'Delete' => 'حذف',
            'storage' => 'ذخیره سازی',
            'public' => 'عمومی',
            'plugins' => 'پلاگین',
            'Size' => 'اندازه',
            'Actions' => 'عملیات',
            'Delete backup: :backup' => 'حذف نسخه پشتیبان: :backup',
            'Creating...' => 'ایجاد...',
        )
	);