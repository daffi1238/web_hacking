<?php

    return array(
        'blocks' => array(
            'Blocks' => 'Blokai',
            'Blocks manager' => 'Blokų tvarkyklė',
            'Delete' => 'Ištrinti',
            'Edit' => 'Redaguoti',
            'Name' => 'Pavadinimas',
            'Create New Block' => 'Sukurti naują bloką',
            'New Block' => 'Naujas blokas',
            'Edit Block' => 'Redaguoti bloką',
            'Save' => 'Išsaugoti',
            'Save and Exit' => 'Išsaugoti ir išeiti',
            'Actions' => 'Veiksmai',
            'Required field' => 'Privalomas laukas',
            'This block already exists' => 'Toks blokas jau yra',
            'This block does not exist' => 'Tokio bloko nėra',
            'Delete block: :block' => 'Ištrinti: :block',
            'Block content' => 'Bloko turinys',
            'Block <i>:name</i> deleted' => 'Blokas <i>:name</i> ištrintas',
            'Your changes to the block <i>:name</i> have been saved.' => 'Bloko <i>:name</i> pakeitimai išsaugoti.',
            'Delete block: :block' => 'Delete block: :block',
            'View Embed Code' => 'View Embed Code',
            'Embed Code' => 'Embed Code',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
