<?php

    return array(
        'plugins' => array(
            'Plugins' => '插件',
            'Name' => '名称',
            'Actions' => '操作',
            'Description' => '描述',
            'Installed' => '已安装',
            'Install New' => '安装新插件',
            'Delete' => '删除',
            'Delete plugin :plugin' => '删除插件 :plugin',
            'This plugin does not exist' => '此插件不存在',
            'Version' => '版本',
            'Author' => '作者',
            'Get More Plugins' => '获取更多插件',
            'Install' => '安装',
            'Uninstall' => '卸载',
        )
    );
