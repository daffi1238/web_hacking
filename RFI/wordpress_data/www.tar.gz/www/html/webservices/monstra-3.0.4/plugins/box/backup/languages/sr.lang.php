<?php

    return array(
        'backup' => array(
            'Backups' => 'Bekapovi',
            'Backup' => 'Backap',
            'Create Backup' => 'Kreiraj Bekap',
            'Delete' => 'Obriši',
            'storage' => 'lokacija arhive',
            'public' => 'Javno',
            'plugins' => 'Dodaci',
            'Size' => 'Veličina',
            'Actions' => 'Akcija',
            'Delete backup: :backup' => 'Obriši bekap: :backup',
            'Creating...' => 'Kreiranje...',
        )
    );
