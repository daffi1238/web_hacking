<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Menu beheer',
            'Edit' => 'Bewerken',
            'Name' => 'Naam',
            'Delete' => 'Verwijderen',
            'Order' => 'Volgorde',
            'Actions' => 'Acties',
            'Create New Item' => 'Nieuw menu',
            'New item' => 'Nieuw menu',
            'Item name' => 'Menu naam',
            'Item order' => 'Menu volgorde',
            'Item target' => 'Menu doel',
            'Item link' => 'Menu link',
            'Item category' => 'Menu categorie',
            'Save' => 'Opslaan',
            'Edit item' => 'Bewerk menu',
            'Delete item :name' => 'Verwijder menu: :name',
            'Select page' => 'Selecteer pagina',
            'Category' => 'Categorie',
            'Select category' => 'Selecteer categorie',
            'Required field' => 'Vereist veld',
            'Cancel' => 'Cancel',
        )
    );
