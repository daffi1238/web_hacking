<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Mapa do site',
        )
    );
