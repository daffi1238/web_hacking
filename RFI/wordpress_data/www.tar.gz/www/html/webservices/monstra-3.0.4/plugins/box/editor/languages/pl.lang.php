<?php

    return array(
        'Editor' => array(
            'Editor' => 'Edytor',
            'Editor plugin' => 'Wtyczka edytora',
        )
    );
