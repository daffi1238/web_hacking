<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Mapa webstánky',
        )
    );
