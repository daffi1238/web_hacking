<?php

    return array(
        'backup' => array(
            'Backups' => 'Бекапы',
            'Backup' => 'Бекап',
            'Create Backup' => 'Сделать бекап',
            'Delete' => 'Удалить',
            'storage' => 'данные',
            'public' => 'публичная',
            'plugins' => 'плагины',
            'Size' => 'Размер',
            'Actions' => 'Действия',
            'Delete backup: :backup' => 'Удалить бекап: :backup',
            'Creating...' => 'Создание...',
            'Backup was deleted' => 'Бекап не был создан',
            'Backup was created' => 'Бекап был создан',
            'Backup was not restored' => 'Бекап не был восстановлен',
            'Backup was restored' => 'Бекап был восстановлен',
        )
    );
