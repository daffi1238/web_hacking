<?php

    return array(
        'blocks' => array(
            'Blocks' => 'Bloklar',
            'Blocks manager' => 'Blok yöneticisi',
            'Delete' => 'Sil',
            'Edit' => 'Düzenle',
            'Name' => 'Ad',
            'Create New Block' => 'Yeni Blok Oluştur',
            'New Block' => 'Yeni Blok',
            'Edit Block' => 'Bloğu Düzenle',
            'Save' => 'Kaydet',
            'Save and Exit' => 'Kaydet ve Çık',
            'Actions' => 'İşlemler',
            'Required field' => 'Zorunlu alan',
            'This block already exists' => 'Bu blok zaten var.',
            'This block does not exist' => 'Blok bulunamadı.',
            'Delete block: :block' => ':block adlı blok silinsin mi',
            'Block content' => 'Blok içeriği',
            'Block <i>:name</i> deleted' => '<i>:name</i> adlı blok silindi.',
            'Your changes to the block <i>:name</i> have been saved.' => 'Değişiklikler <i>:name</i> bloğuna kaydedildi.',
            'Delete block: :block' => ':block adlı blok silinsin mi',
            'View Embed Code' => 'Gömülür Kodu Görüntüle',
            'Embed Code' => 'Gömülür Kodu',
            'Shortcode' => 'Kısa Kod',
            'PHP Code' => 'PHP Kodu',
            'Cancel' => 'Vazgeç',
        )
    );
