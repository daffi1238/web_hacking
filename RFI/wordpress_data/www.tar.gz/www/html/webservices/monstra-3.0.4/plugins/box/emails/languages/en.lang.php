<?php

    return array(
        'emails' => array(
            'Emails' => 'Emails',
            'Emails plugin for Monstra' => 'Emails plugin for Monstra',
            'Edit Layout' => 'Edit Layout',
            'Email templates' => 'Email templates',
            'Edit' => 'Edit',
            'Edit Email Template' => 'Edit Email Template',
            'Name' => 'Name',
            'Email template content' => 'Email template content',
            'Save and Exit' => 'Save and Exit',
            'Save' => 'Save',
            'Cancel' => 'Cancel',
            'This email template does not exist' => 'This email template does not exist',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Your changes to the email template <i>:name</i> have been saved.',
        )
    );
