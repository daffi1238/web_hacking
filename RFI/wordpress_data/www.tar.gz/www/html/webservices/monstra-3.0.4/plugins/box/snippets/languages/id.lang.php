<?php

    return array(
        'snippets' => array(
            'Snippets' => 'Snippets',
            'Snippets manager' => 'Pengelolaan Snippets',
            'Actions' => 'Tindakan',
            'Delete' => 'Hapus',
            'Edit' => 'Perbaiki',
            'Name' => 'Nama',
            'Create New Snippet' => 'Buat Snippet Baru',
            'New Snippet' => 'Snippet Baru',
            'Edit snippet' => 'Perbaiki Snippet',
            'Save' => 'Simpan',
            'Save and Exit' => 'Simpan dan Keluar',
            'This snippet already exists' => 'Snippet ini sudah ada',
            'This snippet does not exist' => 'Snippet ini belum ada',
            'Delete snippet: :snippet' => 'Hapus snippet: :snippet',
            'Snippet content' => 'Isi snippet',
            'Snippet <i>:name</i> deleted' => 'Snippet <i>:name</i> dihapus',
            'Your changes to the snippet <i>:name</i> have been saved.' => 'Perubahan pada snippet <i>:name</i> telah disimpan.',
            'Delete snippet: :snippet' => 'Hapus snippet: :snippet',
            'Required field' => 'Isian yang Diperlukan',
            'View Embed Code' => 'Lihat Kodingan yang Disisipkan',
            'Embed Code' => 'Kode Sisipan',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
        )
    );
