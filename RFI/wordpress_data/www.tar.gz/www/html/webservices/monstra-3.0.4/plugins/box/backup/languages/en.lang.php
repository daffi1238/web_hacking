<?php

    return array(
        'backup' => array(
    		'Backups' => 'Backups',
    		'Backup' => 'Backup',
            'Backup Date' => 'Backup Date',
    		'Create Backup' => 'Create Backup',
    		'Restore' => 'Restore',
    		'Delete' => 'Delete',
            'storage' => 'storage',
            'public' => 'public',
            'plugins' => 'plugins',
            'Size' => 'Size',
            'Actions' => 'Actions',
            'Delete backup: :backup' => 'Delete backup: :backup',
            'Creating...' => 'Creating...',
            'Backup was created' => 'Backup was created',
            'Backup was not created' => 'Backup was not created',
            'Backup was deleted' => 'Backup was deleted',
            'Backup was not deleted' => 'Backup was not deleted',
            'Backup was restored' => 'Backup was restored',
            'Unzip error' => 'Unzip error',
            'Backup was not restored' => 'Backup was not restored',
        )
	);
