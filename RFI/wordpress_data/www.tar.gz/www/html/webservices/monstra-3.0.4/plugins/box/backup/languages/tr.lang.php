<?php

    return array(
        'backup' => array(
    		'Backups' => 'Yedekler',
    		'Backup' => 'Yedek',
            'Backup Date' => 'Yedekleme Tarihi',
    		'Create Backup' => 'Yedek Al',
    		'Delete' => 'Sil',
    		'Restore' => 'Geri Yükle',
            'storage' => 'depo',
            'public' => 'genel',
            'plugins' => 'eklentiler',
            'Size' => 'Boyut',
            'Actions' => 'Eylemler',
            'Delete backup: :backup' => ':backup adlı yedek silinsin mi',
            'Creating...' => 'Oluşturuluyor...',
            'Backup was created' => 'Yedek oluşturuldu',
            'Backup was not created' => 'Yedek oluşturulmadı',
            'Backup was deleted' => 'Yedek silindi',
            'Backup was not deleted' => 'Yedek silinmedi',
            'Backup was restored' => 'Yedek geri yüklendi',
            'Unzip error' => 'Sıkıştırılmış yedeği açma (unzip) hatası',
            'Backup was not restored' => 'Yedek geri yüklenmedi',
        )
	);
