<?php

    return array(
        'backup' => array(
        	'Backups' => 'Kopie zapasowe',
            'Backup Date' => 'Data kopii zapasowej',
    		'Create Backup' => 'Utwórz kopię zapasową',
    		'Delete' => 'Usuń',
            'storage' => 'magazyn',
            'public' => 'publiczny',
            'plugins' => 'wtyczki',
            'Size' => 'Rozmiar',
            'Actions' => 'Akcje',
            'Delete backup: :backup' => 'Czy napewno usunąć kopię zapasową: :backup',
            'Creating...' => 'Tworzenie kopii zapasowej...',
        )
	);
