<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Pluginy',
            'Name' => 'Názov',
            'Actions' => 'Akcie',
            'Description' => 'Popis',
            'Installed' => 'Nainštalované',
            'Install New' => 'Inštalovať nový',
            'Delete' => 'Vymazať',
            'Delete plugin :plugin' => 'Vymazať plugin :plugin',
            'This plugin does not exist' => 'Tento plugin neexistuje',
            'Version' => 'Verzia',
            'Author' => 'Autor',
            'Get More Plugins' => 'Získať viacej pluginov',
            'Install' => 'Inštalovať',
            'Uninstall' => 'Odinštalovať',
            'README.md not found' => 'README.md not found',
        )
    );
