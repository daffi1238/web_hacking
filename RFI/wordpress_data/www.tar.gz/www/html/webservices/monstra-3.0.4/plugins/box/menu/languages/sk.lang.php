<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Manažér menu',
            'Edit' => 'Editovať',
            'Name' => 'Názov',
            'Delete' => 'Vymazať',
            'Order' => 'Poradie',
            'Actions' => 'Akcie',
            'Create New Item' => 'Vytvoriť novú položku',
            'New item' => 'Nová položka',
            'Item name' => 'Názov položky',
            'Item order' => 'Poradie položky',
            'Item target' => 'Cieľ položky',
            'Item link' => 'Odkaz položky',
            'Item category' => 'Kategória položky',
            'Save' => 'Uložiť',
            'Edit item' => 'Editovať položku',
            'Delete item :name' => 'Vymazať položku :name',
            'Select page' => 'Vybrať stránku',
            'Category' => 'Kategória',
            'Select category' => 'Vybrať kategóriu',
            'Required field' => 'Povinné políčko',
            'Cancel' => 'Cancel',
        )
    );
