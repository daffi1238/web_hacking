<?php

    return array(
        'blocks' => array(
            'Blocks' => 'Blocks',
            'Blocks manager' => 'Blocks manager',
            'Delete' => 'Delete',
            'Edit' => 'Edit',
            'Name' => 'Name',
            'Create New Block' => 'Create New Block',
            'New Block' => 'New Block',
            'Edit Block' => 'Edit Block',
            'Save' => 'Save',
            'Save and Exit' => 'Save and Exit',
            'Actions' => 'Actions',
            'Required field' => 'Required field',
            'This block already exists' => 'This block already exists',
            'This block does not exist' => 'This block does not exist',
            'Delete block: :block' => 'Delete block: :block',
            'Block content' => 'Block content',
            'Block <i>:name</i> deleted' => 'Block <i>:name</i> deleted',
            'Your changes to the block <i>:name</i> have been saved.' => 'Your changes to the block <i>:name</i> have been saved.',
            'Delete block: :block' => 'Delete block: :block',
            'View Embed Code' => 'View Embed Code',
            'Embed Code' => 'Embed Code',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
