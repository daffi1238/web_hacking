<?php

    return array(
        'menu' => array(
            'Menu' => 'Meniu',
            'Menu manager' => 'Meniu tvarkyklė',
            'Edit' => 'Redaguoti',
            'Name' => 'Pavadinimas',
            'Delete' => 'Trinti',
            'Order' => 'Eiliškumas',
            'Actions' => 'Veiksmai',
            'Create New Item' => 'Sukurti naują nuorodą',
            'New item' => 'Nauja nuoroda',
            'Item name' => 'Pavadinimas',
            'Item order' => 'Eiliškumas',
            'Item target' => 'Nuorodos atidarymo būdas',
            'Item link' => 'Nuoroda',
            'Item category' => 'Kategorija',
            'Save' => 'Išsaugoti',
            'Edit item' => 'Redaguoti nuorodą',
            'Delete item :name' => 'Ištrinti nuorodą :name',
            'Add page' => 'Pridėti puslapį',
            'Select page' => 'Pasirinkti puslapį',
            'Category' => 'Kategorija',
            'Select category' => 'Pasirinkti kategoriją',
            'Required field' => 'Privalomas laukas',
            'Cancel' => 'Cancel',
        )
    );
