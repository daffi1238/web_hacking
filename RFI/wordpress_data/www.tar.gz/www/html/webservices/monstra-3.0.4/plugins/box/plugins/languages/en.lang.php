<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Name',
            'Actions' => 'Actions',
            'Description' => 'Description',
            'Installed' => 'Installed',
            'Install New' => 'Install New',
            'Delete' => 'Delete',
            'Delete plugin :plugin' => 'Delete plugin :plugin',
            'This plugin does not exist' => 'This plugin does not exist',
            'Version' => 'Version',
            'Author' => 'Author',
            'Get More Plugins' => 'Get More Plugins',
            'Install' => 'Install',
            'Uninstall' => 'Uninstall',
            'README.md not found' => 'README.md not found',
        )
    );
