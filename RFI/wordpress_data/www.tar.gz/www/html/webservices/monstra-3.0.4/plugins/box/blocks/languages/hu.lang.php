<?php

    return array(
        'blocks' => array(
            'Blocks' => 'Blokkok',
            'Blocks manager' => 'Blokk-kezelő',
            'Delete' => 'Törlés',
            'Edit' => 'Szerkesztés',
            'Name' => 'Név',
            'Create New Block' => 'Új blokk készítése',
            'New Block' => 'Új blokk',
            'Edit Block' => 'Blokk szerkesztése',
            'Save' => 'Mentés',
            'Save and Exit' => 'Mentés és Kilépés',
            'Actions' => 'Műveletek',
            'Required field' => 'Kötelező mező',
            'This block already exists' => 'Ez a blokk már létezik',
            'This block does not exist' => 'Ez a blokk nem létezik',
            'Delete block: :block' => 'Blokk törlése: :block',
            'Block content' => 'Blokk tartalma',
            'Block <i>:name</i> deleted' => 'A <i>:name</i> blokk törölve',
            'Your changes to the block <i>:name</i> have been saved.' => 'A <i>:name</i> blokk változtatásai elmentve.',
            'Delete block: :block' => 'Blokk törlése: :block',
            'View Embed Code' => 'Beágyazott kód mutatása',
            'Embed Code' => 'Beágyazott kód',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
