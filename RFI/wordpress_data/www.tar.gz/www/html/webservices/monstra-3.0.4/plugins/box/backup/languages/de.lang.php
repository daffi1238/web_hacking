<?php

    return array(
        'backup' => array(
            'Backups' => 'Backups',
            'Backup' => 'Backup',
            'Create Backup' => 'Erstelle Backup',
            'Delete' => 'Löschen',
            'storage' => 'Speicher',
            'public' => 'Öffentliche',
            'plugins' => 'Plugins',
            'Size' => 'Größe',
            'Actions' => 'Aktionen',
            'Delete backup: :backup' => 'Lösche Backup: :backup',
            'Creating...' => 'Erstellen...',
        )
    );
