<?php

    return array(
        'Editor' => array(
            'Editor' => '编辑器',
            'Editor plugin' => '编辑器插件',
        )
    );
