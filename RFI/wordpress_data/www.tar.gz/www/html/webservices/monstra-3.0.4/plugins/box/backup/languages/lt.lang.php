<?php

    return array(
        'backup' => array(
            'Backups' => 'Atsarginės kopijos',
            'Backup' => 'Atsarginės kopijos data',
            'Create Backup' => 'Sukurti atsarginę kopiją',
            'Delete' => 'Ištrinti',
            'storage' => 'storage',
            'public' => 'public',
            'plugins' => 'plugins',
            'Size' => 'Dydis',
            'Actions' => 'Veiksmai',
            'Delete backup: :backup' => 'Ištrinti: :backup',
            'Creating...' => 'Kuriama...',
        )
    );
