<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Wtyczki',
            'Name' => 'Nazwa',
            'Actions' => 'Akcje',
            'Description' => 'Opis',
            'Installed' => 'Zainstalowane',
            'Install New' => 'Zainstaluj nową',
            'Delete' => 'Usuń',
            'Delete plugin :plugin' => 'Czy napewno usunąć wtyczkę :plugin',
            'This plugin does not exist' => 'Ta wtyczka nie istnieje',
            'Version' => 'Wersja',
            'Author' => 'Autor',
            'Get More Plugins' => 'Pobierz więcej wtyczek',
            'Install' => 'Instaluj',
            'Uninstall' => 'Odinstaluj',
            'README.md not found' => 'README.md not found',
        )
    );
