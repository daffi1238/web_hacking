<?php

    return array(
        'backup' => array(
    		'Backups' => '备份',
            'Backup Date' => '备份日期',
    		'Create Backup' => '创建备份',
    		'Delete' => '删除',
            'storage' => '存储',
            'public' => '公开',
            'plugins' => '插件',
            'Size' => '大小',
            'Actions' => '操作',
            'Delete backup: :backup' => '删除备份: :backup',
            'Creating...' => '正在创建...',
        )
	);