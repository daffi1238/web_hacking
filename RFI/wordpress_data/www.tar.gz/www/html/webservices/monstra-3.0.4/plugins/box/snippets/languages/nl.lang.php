<?php

    return array(
        'snippets' => array(
            'Snippets' => 'Snippets',
            'Snippets manager' => 'Snippet Beheer',
            'Actions' => 'Acties',
            'Delete' => 'Verwijderen',
            'Edit' => 'Bewerken',
            'Name' => 'Naam',
            'Create New Snippet' => 'Nieuwe Snippet',
            'New Snippet' => 'Nieuwe snippet',
            'Edit Snippet' => 'Bewerk snippet',
            'Save' => 'Opslaan',
            'Save and Exit' => 'Opslaan en Terug',
            'This field should not be empty' => 'Dit veld mag niet leeg zijn',
            'This snippet already exists' => 'Deze snippet bestaat al',
            'This snippet does not exist' => 'Deze snippet bestaat niet',
            'Delete snippet: :snippet' => 'Verwijder snippet: :snippet',
            'Snippet content' => 'Snippet inhoud',
            'Snippet <i>:name</i> deleted' => 'Snippet <i>:name</i> is verwijderd',
            'Your changes to the snippet <i>:name</i> have been saved.' => 'De wijzigingen aan snippet <i>:name</i> zijn opgeslagen.',
            'Delete snippet: :snippet' => 'Verwijder snippet: :snippet',
            'Required field' => 'Vereist veld',
            'View Embed Code' => 'Bekijk Insluitcode',
            'Embed Code' => 'Insluitcode',
            'Shortcode' => 'Korte code',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
