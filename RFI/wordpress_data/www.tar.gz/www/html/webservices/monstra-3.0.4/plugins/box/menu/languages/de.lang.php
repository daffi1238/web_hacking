<?php

    return array(
        'menu' => array(
            'Menu' => 'Menü',
            'Menu manager' => 'Menü Manager',
            'Edit' => 'Bearbeiten',
            'Name' => 'Name',
            'Delete' => 'Löschen',
            'Order' => 'Reihenfolge',
            'Actions' => 'Aktionen',
            'Create New Item' => 'Erstelle neuen Eintrag',
            'New item' => 'Neuer Eintrag',
            'Item name' => 'Eintrags Name',
            'Item order' => 'Eintrags Reihenfolge',
            'Item target' => 'Eintrags Ziel',
            'Item link' => 'Eintrags Link',
            'Item category' => 'Eintrags Kategorie',
            'Save' => 'Speichern',
            'Edit item' => 'Bearbeite Eintrag',
            'Delete item :name' => 'Lösche Eintrag :name',
            'Select page' => 'Seite auswählen',
            'Category' => 'Kategorie',
            'Select category' => 'Kategorie auswählen',
            'Required field' => 'Pflichtfeld',
            'Cancel' => 'Abbrechen',
        )
    );
