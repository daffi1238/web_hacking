<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'პანელი',
            'Dashboard plugin for Monstra' => 'პანელი Monstra-თვის',
            'Welcome back' => 'მოგესალმებით',
            'Create New' => 'დამატება',
            'Upload File' => 'ფაილის ატვირთვა',
        )
    );
