<?php

    return array(
        'blocks' => array(
            'Blocks' => 'Block',
            'Blocks manager' => 'Pengelolaan Block',
            'Delete' => 'Hapus',
            'Edit' => 'Perbaiki',
            'Name' => 'Nama',
            'Create New Block' => 'Buat Block Baru',
            'New Block' => 'Block Baru',
            'Edit Block' => 'Edit Block',
            'Save' => 'Simpan',
            'Save and Exit' => 'Simpan dan Keluar',
            'Actions' => 'Tindakan',
            'Required field' => 'Isian yang Dibutuhkan',
            'This block already exists' => 'Block ini sudah ada',
            'This block does not exist' => 'Block ini belum ada',
            'Delete block: :block' => 'Hapus Block: :block',
            'Block content' => 'Isi Block',
            'Block <i>:name</i> deleted' => 'Block <i>:nama</i> dihapus',
            'Your changes to the block <i>:name</i> have been saved.' => 'Perubahan pada block <i>:nama</i> telah disimpan.',
            'Delete block: :block' => 'Hapus Block: :block',
            'View Embed Code' => 'Lihat Embed Code',
            'Embed Code' => 'Embed Code',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
        )
    );
