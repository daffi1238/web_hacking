<?php

    return array(
        'snippets' => array(
            'Snippets' => 'Snippets',
            'Snippets manager' => 'Snippets manager',
            'Actions' => 'Műveletek',
            'Delete' => 'Töröl',
            'Edit' => 'Szerkeszt',
            'Name' => 'Név',
            'Create New Snippet' => 'Új Snippet készítése',
            'New Snippet' => 'Új Snippet',
            'Edit Snippet' => 'Snippet szerkesztése',
            'Save' => 'Mentés',
            'Save and Exit' => 'Mentés és Kilépés',
            'This snippet already exists' => 'Ez a snippet már létezik',
            'This snippet does not exist' => 'Ez a snippet nem létezik',
            'Delete snippet: :snippet' => 'Snippet törlés: :snippet',
            'Snippet content' => 'Snippet tartalom',
            'Snippet <i>:name</i> deleted' => 'A <i>:name</i> Snippet törölve',
            'Your changes to the snippet <i>:name</i> have been saved.' => 'YA változtatások <i>:name</i> elmentve.',
            'Delete snippet: :snippet' => 'Snippet törlés: :snippet',
            'Required field' => 'Kötelező mező',
            'View Embed Code' => 'View Embed Code',
            'Embed Code' => 'Embed Code',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
