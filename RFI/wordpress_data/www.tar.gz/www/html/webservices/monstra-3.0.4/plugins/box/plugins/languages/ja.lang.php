<?php

    return array(
        'plugins' => array(
            'Plugins' => 'プラグイン',
            'Name' => '名前',
            'Actions' => '操作',
            'Description' => '説明',
            'Installed' => 'インストール済み',
            'Install New' => 'インストール可能',
            'Delete' => '削除',
            'Delete plugin :plugin' => 'プラグインの削除: :plugin',
            'This plugin does not exist' => 'プラグインが存在しません。',
            'Version' => 'バージョン',
            'Author' => '作成者',
            'Get More Plugins' => 'さらにプラグインを取得',
            'Install' => 'インストール',
            'Uninstall' => '停止',
            'README.md not found' => 'README.md not found',
        )
    );
