<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Dashboard',
            'Dashboard plugin for Monstra' => 'Dashboard plugin for Monstra',
            'Welcome back' => 'Welcome back',
            'Create New' => 'Create New',
            'Upload File' => 'Upload File',
        )
    );
