<?php

    return array(
        'backup' => array(
            'Backups' => 'Backup',
            'Backup' => 'Backup',
            'Create Backup' => 'Crea Backup',
            'Delete' => 'Elimina',
            'storage' => 'dati',
            'public' => 'pubblica',
            'plugins' => 'plugin',
            'Size' => 'Dimensione',
            'Actions' => 'Azioni',
            'Delete backup: :backup' => 'Elimina backup: :backup',
            'Creating...' => 'Creazione...',
        )
    );
