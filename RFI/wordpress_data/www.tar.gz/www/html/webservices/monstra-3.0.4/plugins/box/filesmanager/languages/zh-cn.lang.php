<?php

    return array(
        'filesmanager' => array(
            'Files' => '文件',
            'Files manager' => '文件管理',
            'Name' => '名称',
            'Actions' => '操作',
            'Delete' => '删除',
            'Upload' => '上传',
            'directory' => '目录',
            'Delete directory: :dir' => '删除目录: :dir',
            'Delete file: :file' => '删除文件 :file',
            'Extension' => '扩展名',
            'Size' => '尺寸',
			'Select file' => '选择文件',
            'Change' => '更改',
        )
    );
