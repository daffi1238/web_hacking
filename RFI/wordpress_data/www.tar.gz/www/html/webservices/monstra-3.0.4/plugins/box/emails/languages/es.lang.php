<?php

    return array(
        'emails' => array(
            'Emails' => 'Emails',
            'Emails plugin for Monstra' => 'Emails plugin for Monstra',
            'Edit Layout' => 'Editar diseño',
            'Email templates' => 'Plantillas de email',
            'Edit' => 'Editar',
            'Edit Email Template' => 'Editar plantilla de email',
            'Name' => 'Nombre',
            'Email template content' => 'Contenido de la plantilla de email',
            'Save and Exit' => 'Guardar y salir',
            'Save' => 'Guardar',
            'Cancel' => 'Cancelar',
            'This email template does not exist' => 'Esta plantilla de email no existe',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Tus cambios en la plantilla de email <i>:name</i> han sido guardados.',
        )
    );
