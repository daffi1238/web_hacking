<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Dashboard',
            'Dashboard plugin for Monstra' => 'Dashboard plugin für Monstra',
            'Welcome back' => 'Willkommen zurück',
            'Create New' => 'Erstelle neue',
            'Upload File' => 'Datei hochladen',
        )
    );
