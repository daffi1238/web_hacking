<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Eklentiler',
            'Name' => 'Ad',
            'Actions' => 'İşlemler',
            'Description' => 'Açıklama',
            'Installed' => 'Yüklenenler',
            'Install New' => 'Yeni Yükle',
            'Delete' => 'Sil',
            'Delete plugin :plugin' => ':plugin adlı eklenti silinsin mi',
            'This plugin does not exist' => 'Eklenti bulunamadı',
            'Version' => 'Sürüm',
            'Author' => 'Yazar',
            'Get More Plugins' => 'Daha Fazla Eklenti',
            'Install' => 'Yükle',
            'Uninstall' => 'Kaldır',
        )
    );
