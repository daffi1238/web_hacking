<?php

    return array(
        'menu' => array(
            'Menu' => 'Меню',
            'Menu manager' => 'Менеджер меню',
            'Edit' => 'Редагувати',
            'Name' => 'Назва',
            'Delete' => 'Видалити',
            'Order' => 'Порядок',
            'Actions' => 'Дії',
            'Create New Item' => 'Створити новий пункт меню',
            'New item' => 'Новий пункт меню',
            'Item name' => 'Назва',
            'Item order' => 'Порядок',
            'Item target' => 'Ціль',
            'Item link' => 'Ссылка',
            'Item category' => 'Категорія',
            'Save' => 'Зберегти',
            'Edit item' => 'Редагування пункту меню',
            'Delete item :name' => 'Видалити пункт меню :name',
            'Select page' => 'Вибрати сторінку',
            'Category' => 'Категорія',
            'Select category' => 'Вибрати категорію',
            'Required field' => 'Обов’язкове поле',
            'Cancel' => 'Cancel',
        )
    );
