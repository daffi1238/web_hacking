<?php

    return array(
        'Editor' => array(
            'Editor' => 'Editeur',
            'Editor plugin' => 'Plugin éditeur',  
        )
    );