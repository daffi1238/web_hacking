<?php

    return array(
        'menu' => array(
            'Menu' => 'მენიუ',
            'Menu manager' => 'მენიუს მენეჯერი',
            'Edit' => 'რედაქტირება',
            'Name' => 'სახელწოდება',
            'Delete' => 'წაშლა',
            'Order' => 'რიგი',
            'Actions' => 'მოქმედება',
            'Create New Item' => 'მენიუს ახალი პუნქტის შექმნა',
            'New item' => 'მენიუს ახალი პუნქტი',
            'Item name' => 'სახელი',
            'Item order' => 'რიგი',
            'Item target' => 'მიზანი',
            'Item link' => 'ბმული',
            'Item category' => 'კატეგორია',
            'Save' => 'შენახვა',
            'Edit item' => 'მენიუს პუნქტის რედაქტირება',
            'Delete item :name' => 'მენიუს პუქტის წაშლა :name',
            'Select page' => 'გვერდის არჩევა',
            'Category' => 'კატეგორია',
            'Select category' => 'კატეგორიის არჩევა',
            'Required field' => 'აუცილებელი ველი',
            'Cancel' => 'გაუქმება',
        )
    );
