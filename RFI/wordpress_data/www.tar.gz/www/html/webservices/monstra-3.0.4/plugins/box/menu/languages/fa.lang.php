<?php

    return array(
        'menu' => array(
            'Menu' => 'منو',        
            'Menu manager' => 'مدیریت منو',
            'Edit' => 'ویرایش',
            'Name' => 'نام',
            'Delete' => 'حذف',
            'Order' => 'ترتیب',
            'Actions' => 'عملیات',
            'Create New Item' => 'ایجاد آیتم جدید',
            'New item' => 'آیتم جدید',
            'Item name' => 'نام آیتم',
            'Item order' => 'ترتیب آیتم',
            'Item target' => 'هدف آیتم',
            'Item link' => 'لینک آیتم',
            'Item category' => 'مجموعه آیتم',
            'Save' => 'ذخیره',
            'Edit item' => 'ویرایش آیتم',
            'Delete item :name' => 'حذف آیتم :name',
            'Select page' => 'انتخاب صفحه',
            'Category' => 'مجموعه',
            'Select category' => 'انتخاب مجموعه',
            'Required field' => 'کادر الزامی',
            'Cancel' => 'Cancel',
        )
    );
