<?php

    return array(
        'Editor' => array(
            'Editor' => 'Szerkesztő',
            'Editor plugin' => 'Szerkesztő bővítmény',
        )
    );
