<?php

    return array(
        'backup' => array(
            'Backups' => 'Backups',
            'Backup' => 'Backup',
            'Create Backup' => 'Maak backup',
            'Delete' => 'Verwijderen',
            'storage' => 'Opslag',
            'public' => 'Publiek',
            'plugins' => 'Plugins',
            'Size' => 'Grootte',
            'Actions' => 'Acties',
            'Delete backup: :backup' => 'Verwijder backup: :backup',
            'Creating...' => 'Backup wordt gemaakt...',
        )
    );
