<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',        
            'Menu manager' => 'Menu menadžer',
            'Edit' => 'Izmeni',
            'Name' => 'Ime',
            'Delete' => 'Obriši',
            'Order' => 'Poređenje',
            'Actions' => 'Akcije',
            'Create new item' => 'Kreiraj novu stavku',
            'New item' => 'Nova stavka',
            'Item name' => 'Ime',
            'Item order' => 'Poredjenje',
            'Item target' => 'Otvaranje stranice',
            'Item link' => 'Link',
            'Item category' => 'Kategorija',
            'Save' => 'Sačuvaj',
            'Edit item' => 'Izmeni',
            'Delete item :name' => 'Obriši stavku :name',
            'Select page' => 'Odaberi stranicu',
            'Category' => 'Kategorija',
            'Select category' => 'Odaberi kategoriju',
            'Required field' => 'Polje je potrebno',
            'Cancel' => 'Otkaži',
        )
    );
