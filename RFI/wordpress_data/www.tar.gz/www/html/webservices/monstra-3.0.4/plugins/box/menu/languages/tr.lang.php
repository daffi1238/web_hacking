<?php

    return array(
        'menu' => array(
            'Menu' => 'Menü',
            'Menu manager' => 'Menü Yöneticisi',
            'Edit' => 'Düzenle',
            'Name' => 'Ad',
            'Delete' => 'Sil',
            'Order' => 'Sıra',
            'Actions' => 'İşlemler',
            'Create New Item' => 'Yeni Bağlantı Oluştur',
            'New item' => 'Yeni bağlantı',
            'Item name' => 'Bağlantı adı',
            'Item order' => 'Bağlantı sırası',
            'Item target' => 'Bağlantı hedefi',
            'Item link' => 'Bağlantı yolu',
            'Item category' => 'Bağlantı kategorisi',
            'Save' => 'Kaydet',
            'Edit item' => 'Bağlantıyı düzenle',
            'Delete item :name' => ':name adlı bağlantıyı sil',
            'Select page' => 'Sayfa seç',
            'Category' => 'Kategori',
            'Select category' => 'Kategori seç',
            'Required field' => 'Zorunlu alan',
            'Cancel' => 'Vazgeç',
        )
    );
