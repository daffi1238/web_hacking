<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Pengelolaan Menu',
            'Edit' => 'Perbaiki',
            'Name' => 'Nama',
            'Delete' => 'Hapus',
            'Order' => 'Urutan',
            'Actions' => 'Tindakan',
            'Create New Item' => 'Buat Perihal Baru',
            'New item' => 'Perihal Baru',
            'Item name' => 'Nama Perihal',
            'Item order' => 'Urutan Perihal',
            'Item target' => 'Target Perihal',
            'Item link' => 'Link Perihal',
            'Item category' => 'Kategori Perihal',
            'Save' => 'Simpan',
            'Edit item' => 'Perbaiki Perihal',
            'Delete item :name' => 'Hapus perihal :nama',
            'Select page' => 'Pilih Halaman',
            'Category' => 'Kategori',
            'Select category' => 'Pilih Kategori',
            'Required field' => 'Isian yang Dibutuhkan',
        )
    );
