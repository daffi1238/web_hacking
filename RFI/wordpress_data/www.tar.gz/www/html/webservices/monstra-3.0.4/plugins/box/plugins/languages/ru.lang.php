<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Плагины',
            'Installed' => 'Установленные',
            'Install New' => 'Установить новые',
            'Actions' => 'Действия',
            'Name' => 'Название',
            'Description' => 'Описание',
            'Delete' => 'Удалить',
            'Delete plugin :plugin' => 'Удалить плагин :plugin',
            'This plugin does not exist' => 'Такого плагина не существует',
            'Version' => 'Версия',
            'Author' => 'Автор',
            'Get More Plugins' => 'Скачать другие плагины',
            'Install' => 'Установить',
            'Uninstall' => 'Удалить',
            'README.md not found' => 'README.md не найден',
            'Info' => 'Инфо',
            'Upload' => 'Загрузить',
            'Drop File Here' => 'Перетащите файл сюда',
        )
    );
