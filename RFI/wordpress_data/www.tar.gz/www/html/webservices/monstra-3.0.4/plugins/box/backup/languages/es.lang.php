<?php

    return array(
            'backup' => array(
    	       'Backups' => 'Backups',
	       'Backup' => 'Backup',
            'Backup Date' => 'Fecha del backup',
    	       'Create Backup' => 'Crear backup',
	       'Restore' => 'Restaurar', 
	       'Delete' => 'Eliminar',
            'storage' => 'Almacenamiento',
            'public' => 'público',
            'plugins' => 'plugins',
            'Size' => 'Tamaño',
            'Actions' => 'Acciones',
            'Delete backup: :backup' => 'Eliminar backup: :backup',
            'Creating...' => 'Creando...', 
            'Backup was created' => 'El backup fue creado',
            'Backup was not created' => 'El backup no fue creado',
            'Backup was deleted' => 'El backup fue eliminado',
            'Backup was not deleted' => 'El backup no fue eliminado',
            'Backup was restored' => 'El backup fue restaurado',
            'Unzip error' => 'Error de descompresión',
            'Backup was not restored' => 'El backup no fue restaurado',
        )
	);
