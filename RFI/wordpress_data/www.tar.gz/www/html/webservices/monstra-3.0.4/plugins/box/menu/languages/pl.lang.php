<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Zarządzaj menu',
            'Edit' => 'Edytuj',
            'Name' => 'Nazwa',
            'Delete' => 'Usuń',
            'Order' => 'Kolejność',
            'Actions' => 'Akcje',
            'Create New Item' => 'Utwórz nową pozycję',
            'New item' => 'Nowa pozycja',
            'Item name' => 'Nazwa pozycji',
            'Item order' => 'Kolejność pozycji',
            'Item target' => 'Cel pozycji',
            'Item link' => 'Łącze pozycji',
            'Item category' => 'Kategoria pozycji',
            'Save' => 'Zapisz',
            'Edit item' => 'Edytuj pozycję',
            'Delete item :name' => 'Czy napewno usunąć pozycję :name',
            'Select page' => 'Wybierz stronę',
            'Category' => 'Kategoria',
            'Select category' => 'Wybierz kategorię',
            'Required field' => 'Pole wymagane',
            'Cancel' => 'Cancel',
        )
    );
