<?php

    return array(
        'backup' => array(
    		'Backups' => 'バックアップ',
            'Backup Date' => 'バックアップ日',
    		'Create Backup' => 'バックアップの作成',
    		'Delete' => '削除',
            'storage' => 'ストレージ',
            'public' => '公開',
            'plugins' => 'プラグイン',
            'Size' => 'サイズ',
            'Actions' => 'アクション',
            'Delete backup: :backup' => 'バックアップの削除: :backup',
            'Creating...' => '作成中...',
        )
	);
